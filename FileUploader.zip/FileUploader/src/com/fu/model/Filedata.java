package com.fu.model;

import javax.persistence.*;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name="files")
public class Filedata {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sno;
	@Column(name="id")
	private String id;
	@Column(name="name")
	private String name;
	@Column(name="department")
	private String dept;
	@Column(name="course")
	private String course;
	@Column(name="topic_name")
	private String topic_name;
	@Column(name="filename")
	private String filename;
	@Column(name="status")
	private String status;
	@Column(name="marks")
	private String mark;
	@Column(name="seen")
	private int seen;
	@Column(name="submission_count")
	private int count;
	public int getSeen() {
		return seen;
	}
	public void setSeen(int seen) {
		this.seen = seen;
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getTopic_name() {
		return topic_name;
	}
	public void setTopic_name(String topic_name) {
		this.topic_name = topic_name;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	
	public String getMark() {
		return mark;
	}
	public void setMark(String mark) {
		this.mark = mark;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Filedata() {
		super();
	}
	public Filedata(String id, String name, String dept, String course, String topic_name, String filename,
			String status, String mark, int count) {
		super();
		this.id = id;
		this.name = name;
		this.dept = dept;
		this.course = course;
		this.topic_name = topic_name;
		this.filename = filename;
		this.status = status;
		this.mark = mark;
		this.count = count;
	}
	
}
