package com.fu.model;

import javax.persistence.*;

@Entity
@Table(name="signup")
public class Signup {
	@Id
	@Column(name="id")
	private String id;
	@Column(name="name")
	private String name;
	@Column(name="course")
	private String course;
	@Column(name="year")
	private String year;
	@Column(name="department")
	private String dept;
	@Column(name="type")
	private String type;
	@Column(name="username")
	private String uname;
	@Column(name="password")
	private String pwd;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public Signup(String id, String name, String course, String year, String dept, String type, String uname,
			String pwd) {
		super();
		this.id = id;
		this.name = name;
		this.course = course;
		this.year = year;
		this.dept = dept;
		this.type = type;
		this.uname = uname;
		this.pwd = pwd;
	}
	
}
