package com.fu.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name="questions")
public class Tasksupload {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sno;
	@Column(name="topic_name")
	private String topic_name;
	@Column(name="question")
	private String question;
	@Column(name="course")
	private String course;
	@Column(name="filename")
	private String filename;
	@Column(name="lastdate")
	private Date ldate;
	public String getTopic_name() {
		return topic_name;
	}
	public void setTopic_name(String topic_name) {
		this.topic_name = topic_name;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public Date getLdate() {
		return ldate;
	}
	public void setLdate(Date ldate) {
		this.ldate = ldate;
	}
	public Tasksupload(String topic_name, String question, String course, Date ldate) {
		super();
		this.topic_name = topic_name;
		this.question = question;
		this.course = course;
		this.ldate = ldate;
	}
	public Tasksupload() {
		super();
	}
	
}
