package com.fu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="studymaterials")
public class Studymaterials {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int s_no;
	@Column(name="filename")
	private String filename;
	@Column(name="course")
	private String course;
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	
}
