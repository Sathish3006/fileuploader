package com.fu.dao;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.fu.model.Filedata;
import com.fu.model.Oldsubmissions;
import com.fu.model.Signup;
import com.fu.model.Studymaterials;
import com.fu.model.Tasksupload;
import com.fu.model.Userfilter;

@Repository
public class ProjectDAO {
	@Autowired
	SessionFactory sf;
	@Autowired
	HttpSession hs;
	@Transactional
	public String loginvalidate(Signup ss) {
		Session s = sf.getCurrentSession();
		try {
			Query q = s.createQuery("select s.id from Signup s where s.uname='"+ss.getUname()+"' and s.pwd='"+ss.getPwd()+"'");
			List<String> uid = q.list();
			if(uid.isEmpty()) {
				return null;
			}
			return uid.get(0);
		}
		catch(Exception e) {
			return null;
		}
		//System.out.println(uid.get(0));
	}
	@Transactional
	public String userposition(String id) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.type from Signup s where s.id='"+id+"'");
		List<String> type = q.list();
		System.out.println(type.get(0));
		return type.get(0);
	}
	@Transactional
	public void signupuser(Signup ss) {
		Session s = sf.getCurrentSession();
		s.save(ss);
	}
	@Transactional
	public String username(String id) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.name from Signup s where s.id='"+id+"'");
		List<String> name = q.list();
		System.out.println(name.get(0));
		return name.get(0);
	}
	@Transactional
	public String usercourse(String id) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.course from Signup s where s.id='"+id+"'");
		List<String> name = q.list();
		System.out.println(name.get(0));
		return name.get(0);
	}
	public File convert(MultipartFile file) throws IOException{
		File convfile=new File(file.getOriginalFilename());
		convfile.createNewFile();
		FileOutputStream fo = new FileOutputStream(convfile);
		fo.write(file.getBytes());
		fo.close();
		return convfile;
	}
	@Transactional
	public void signupmany(File files){
		Session s = sf.getCurrentSession();
		String[] as = new String[8];
		try{
			FileInputStream file = new FileInputStream(files);
			XSSFWorkbook wb = new XSSFWorkbook(file);
			XSSFSheet sheet = wb.getSheetAt(0);
			Iterator<Row> iterator = sheet.iterator();
			DataFormatter df = new DataFormatter();
			int count=0;
			while(iterator.hasNext()){
				count=0;
				Row row = iterator.next();
				Iterator<Cell> celliterator = row.cellIterator(); 
				while(celliterator.hasNext()){
					Cell cell = celliterator.next();
						as[count]=String.valueOf(df.formatCellValue(cell));
					count++;
				}
				Signup su = new Signup(as[0],as[1],as[2].toLowerCase(),as[3],as[4],as[5],as[6],as[7]);
				s.save(su);
				System.out.println();
			}
			System.out.println("Values Inserted!..");
		}
		catch(Exception e){
			System.out.println("Error");
			e.printStackTrace();
		}
	}
	@Transactional
	public long countseen() {
		Session s = sf.getCurrentSession();
		Query qseen = s.createQuery("select count(s.seen) from Filedata s where s.course='"+hs.getAttribute("course")+"' and s.seen=1");
		long seen = (Long)qseen.list().get(0);
		return seen;
	}
	@Transactional
	public void uploadtask(com.fu.model.File files,HttpServletRequest request){
		Session s = sf.getCurrentSession();
		Tasksupload tu = new Tasksupload();
		tu.setCourse(hs.getAttribute("course").toString());
		tu.setLdate(files.getLdate());
		tu.setQuestion(files.getQuestion());
		tu.setTopic_name(files.getTopic_name());
		
		if(files.getFile()!=null) {
			tu.setFilename(files.getFile().getOriginalFilename());
			try {
				File ff = new File(request.getServletContext().getRealPath("Files/"));
				System.out.println(ff.toString());
				File file= new File(ff.toString()+"\\"+hs.getAttribute("course"));
		        if (!file.exists()) {
		            if (file.mkdir()) {
		            }
		        }
		        File file1 = new File(file.toString()+"\\"+tu.getTopic_name());
		        if (!file1.exists()) {
		            if (file1.mkdir()) {
		            }
		        }
		        InputStream is = files.getFile().getInputStream();
				OutputStream os=null;
		        if(files.getFile().getSize()>0){
				is=files.getFile().getInputStream();
				os=new FileOutputStream(file1+"\\"+tu.getFilename());
				byte[] byt = new byte[81920];
				int readbytes=0;
				while((readbytes=is.read(byt,0,81920))!=-1){
					os.write(byt, 0, readbytes);
				}
				os.close();
				is.close();
			}
			}
			catch(Exception e) {
				System.out.println("Failed!");
				e.printStackTrace();
			}
		}
		s.save(tu);
	}
	@Transactional
	public List getTask() {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.topic_name,DATEDIFF(s.ldate,CURRENT_DATE()) from Tasksupload s where s.course='"+hs.getAttribute("course").toString()+"'");
		List<Tasksupload[]> task = (List<Tasksupload[]>) q.list();
		for(Object[] sa:task) {
			try {
				List<String> q1 = s.createQuery("select s.filename from Filedata s where s.id='"+hs.getAttribute("id")+"' and s.topic_name='"+(String)sa[0]+"'").list();
				System.out.println(q1.get(0));
				sa[1]=(int)10000;
			}
			catch(Exception e) {
			}
		}
		return task;
	}
	@Transactional
	public String taskdetails(String name) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.question from Tasksupload s where s.topic_name='"+name+"' and s.course='"+hs.getAttribute("course")+"'");
		List<String> task = q.list();
		return task.get(0);
	}
	@Transactional
	public String taskfilename(String name) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.filename from Tasksupload s where s.topic_name='"+name+"' and s.course='"+hs.getAttribute("course")+"'");
		List<String> task = q.list();
		if(task.isEmpty()) {
			return null;
		}
		return task.get(0);
	}
	@Transactional
	public Date tasklastdate(String name) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.ldate from Tasksupload s where s.topic_name='"+name+"' and s.course='"+hs.getAttribute("course")+"'");
		List<java.sql.Date> task = q.list();
		return task.get(0);
	}
	@Transactional
	public List edittask() {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.topic_name from Tasksupload s where s.course='"+hs.getAttribute("course").toString()+"' and s.course='"+hs.getAttribute("course")+"'");
		List<Tasksupload[]> task = (List<Tasksupload[]>) q.list();
		return task;
	}
	@Transactional
	public int taskdatedetails(String name) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select DATEDIFF(s.ldate,CURRENT_DATE()) from Tasksupload s where s.topic_name='"+name+"' and s.course='"+hs.getAttribute("course")+"'");
		int d= (int) q.list().get(0);
		return d;
	}
	@Transactional
	public void updatetaskdetails(com.fu.model.File files,HttpServletRequest request) {
		Session s = sf.getCurrentSession();
		Tasksupload tu = new Tasksupload();
		tu.setCourse(hs.getAttribute("course").toString());
		tu.setLdate(files.getLdate());
		tu.setQuestion(files.getQuestion());
		tu.setTopic_name(files.getTopic_name());
		if(files.getFile()!=null) {
			tu.setFilename(files.getFile().getOriginalFilename());
			try {
				File ff = new File(request.getServletContext().getRealPath("Files/"));
				System.out.println(ff.toString());
				File file= new File(ff.toString()+"\\"+hs.getAttribute("course"));
		        if (!file.exists()) {
		            if (file.mkdir()) {
		            }
		        }
		        File file1 = new File(file.toString()+"\\"+tu.getTopic_name());
		        if (!file1.exists()) {
		            if (file1.mkdir()) {
		            }
		        }
		        InputStream is = files.getFile().getInputStream();
				OutputStream os=null;
		        if(files.getFile().getSize()>0){
				is=files.getFile().getInputStream();
				os=new FileOutputStream(file1+"\\"+tu.getFilename());
				byte[] byt = new byte[81920];
				int readbytes=0;
				while((readbytes=is.read(byt,0,81920))!=-1){
					os.write(byt, 0, readbytes);
				}
				os.close();
				is.close();
			}
			}
			catch(Exception e) {
				System.out.println("Failed!");
				e.printStackTrace();
			}
			Query qq = s.createQuery("update Tasksupload s set s.filename='"+tu.getFilename()+"',s.question='"+tu.getQuestion()+"',s.ldate='"+tu.getLdate()+"' where s.topic_name='"+tu.getTopic_name()+"' and s.course='"+hs.getAttribute("course")+"'");
			qq.executeUpdate();
		}
		else {
			Query qq = s.createQuery("update Tasksupload s set s.filename=NULL,s.question='"+tu.getQuestion()+"',s.ldate='"+tu.getLdate()+"' where s.topic_name='"+tu.getTopic_name()+"' and s.course='"+hs.getAttribute("course")+"'");
			qq.executeUpdate();
		}
	}
	@Transactional
	public void fileupload(com.fu.model.File fd,HttpServletRequest request) throws IOException {
		Session s = sf.getCurrentSession();
		MultipartFile mf = fd.getFile();
		int cc;
		Filedata fd1 = new Filedata();
		fd1.setTopic_name(fd.getTopic_name());
		String timestamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
		fd1.setFilename(timestamp+"_"+mf.getOriginalFilename());
		try {
			List q1 = s.createQuery("select s.count from Filedata s where s.id='"+hs.getAttribute("id")+"' and s.topic_name='"+fd.getTopic_name()+"'").list();
			cc = (int)q1.get(0);
			System.out.println(cc);
			cc++;
			fd1.setCount(cc);
			//System.out.println(cc+"Executed");
		}
		catch(Exception e) {
			fd1.setCount(1);
			System.out.println(fd1.getCount()+"Failed");
		}
		List<String> dt = s.createQuery("select s.dept from Signup s where s.id='"+hs.getAttribute("id")+"'").list();
		Oldsubmissions oss = new Oldsubmissions();
		oss.setId(hs.getAttribute("id").toString());
		oss.setDept(dt.get(0));
		oss.setCourse(hs.getAttribute("course").toString());
		oss.setFilename(fd1.getFilename());
		oss.setTopic_name(fd.getTopic_name());
		s.save(oss);
		//try {
			Query q = s.createQuery("delete from Filedata f where f.id='"+hs.getAttribute("id")+"' and f.topic_name='"+fd.getTopic_name()+"'");
			q.executeUpdate();
			//}
		//catch(Exception e) {
			
		//}
		System.out.println(fd1.getFilename());
		fd1.setId(hs.getAttribute("id").toString());
		fd1.setDept(dt.get(0));
		fd1.setName(hs.getAttribute("name").toString());
		fd1.setCourse(hs.getAttribute("course").toString());
		Query qq= s.createQuery("select DATEDIFF(s.ldate,CURRENT_DATE()) from Tasksupload s where s.topic_name='"+fd1.getTopic_name()+"' and s.course='"+hs.getAttribute("course")+"'");
		int diff = (int)qq.list().get(0);
		InputStream is = mf.getInputStream();
		OutputStream os=null;
		File ff = new File(request.getServletContext().getRealPath("Files/"));
		File file2 = new File(ff.toString()+"\\"+hs.getAttribute("course").toString());
        if (!file2.exists()) {
            if (file2.mkdir()) {
            }
        }
		File file = new File(file2.toString()+"\\"+hs.getAttribute("id").toString());
        if (!file.exists()) {
            if (file.mkdir()) {
            }
        }
        File file1 = new File(file.toString()+"\\"+fd1.getTopic_name());
        if (!file1.exists()) {
            if (file1.mkdir()) {
            }
        }
        System.out.println(file);
        if(diff>=0) {
			fd1.setStatus("Submitted");
		}
		else {
			fd1.setStatus("Overdue");
		}
		if(mf.getSize()>0){
			is=mf.getInputStream();
			os=new FileOutputStream(file1+"\\"+fd1.getFilename());
			byte[] byt = new byte[81920];
			int readbytes=0;
			while((readbytes=is.read(byt,0,81920))!=-1){
				os.write(byt, 0, readbytes);
			}
			os.close();
			is.close();
		}
		fd1.setSeen(1);
		s.save(fd1);
		System.out.println("Success");
	}
	@Transactional
	public String filedownload(String name) throws IOException {
		Session s = sf.getCurrentSession();
		try {
			List<String> q = s.createQuery("select s.filename from Filedata s where s.id='"+hs.getAttribute("id")+"' and s.topic_name='"+name+"'").list();
			return "F:\\Devops Project\\FileUploader\\WebContent\\Files\\"+hs.getAttribute("id").toString()+"\\"+name+"\\"+q.get(0);
		}
		catch(Exception e) {
			return null;
		}
	}
	@Transactional
	public List studentdetails(){
		Session s = sf.getCurrentSession();
		List<Signup[]> q =(List<Signup[]>) s.createQuery("select s.id,s.name,s.year,s.dept,s.uname from Signup s where s.course='"+hs.getAttribute("course")+"' and s.type='student'").list();
		return q;	
	}
	@Transactional
	public List stafftaskname(){
		Session s = sf.getCurrentSession();
		List<Signup[]> q =(List<Signup[]>) s.createQuery("select s.topic_name,s.course from Tasksupload s where s.course='"+hs.getAttribute("course")+"'").list();
		for(Object[] ts:q) {
			Query qseen = s.createQuery("select count(s.seen) from Filedata s where s.course='"+hs.getAttribute("course")+"' and s.seen=1 and s.topic_name='"+ts[0]+"'");
			long seen = (Long)qseen.list().get(0);
			ts[1] = seen;
		}
		return q;	
	}
	@Transactional
	public List stafftaskdetails(String name){
		Session s = sf.getCurrentSession();
		List<Filedata[]> q = (List<Filedata[]>)s.createQuery("select s.id,s.name,s.filename,s.dept,s.status,s.count,s.mark from Filedata s where s.topic_name='"+name+"' and s.course='"+hs.getAttribute("course")+"'").list();
		return q;	
	}
	@Transactional
	public List userdetails(){
		Session s = sf.getCurrentSession();
		List<Signup[]> q = (List<Signup[]>)s.createQuery("select s.id,s.name,s.course,s.year,s.dept,s.uname,s.pwd from Signup s where s.id='"+hs.getAttribute("id")+"'").list();
		return q;	
	}
	@Transactional
	public void updateprofile(Signup ss) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("update from Signup s set s.name='"+ss.getName()+"',s.pwd='"+ss.getPwd()+"' where s.id='"+hs.getAttribute("id")+"'");
		q.executeUpdate();
		List<String> qq = s.createQuery("select s.name from Signup s where s.id='"+hs.getAttribute("id")+"'").list();
		hs.setAttribute("name",qq.get(0).toString() );
	}
	@Transactional
	public void markupdate(Filedata fd){
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("update Filedata f set f.mark='"+fd.getMark()+"' where f.id='"+fd.getId()+"' and f.topic_name='"+fd.getTopic_name()+"'");	
		q.executeUpdate();
		Query qq = s.createQuery("update Filedata s set s.seen=0 where s.topic_name='"+fd.getTopic_name()+"' and s.course='"+hs.getAttribute("course")+"' and s.id='"+fd.getId()+"'");
		qq.executeUpdate();
	}
	@Transactional
	public List viewuser(Signup ss) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.id,s.name,s.course,s.year,s.dept,s.type,s.uname,s.pwd from Signup s where s.id='"+ss.getId()+"'");
		List<Signup[]> li = (List<Signup[]>) q.list();
		return li;
	}
	@Transactional
	public void deleteuser(Signup ss) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("delete from Signup s where s.id='"+ss.getId()+"'");
		q.executeUpdate();
		Query q1 = s.createQuery("delete from Filedata f where f.id='"+ss.getId()+"'");
		q1.executeUpdate();
	}
	@Transactional
	public List adminuserdetails() {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.id,s.name,s.course,s.dept,s.type from Signup s where s.type!='admin'");
		return q.list();
	}
	@Transactional
	public List adminfilter(Userfilter uf){
		Session s = sf.getCurrentSession();
		Query query = null;
		if(uf.getType().equals("all")){
			query = s.createQuery("select s.id,s.name,s.course,s.dept,s.type from Signup s where s.type!='admin'");
		}
		else if(uf.getType().equals("id")){
			query  = s.createQuery("select s.id,s.name,s.course,s.dept,s.type from Signup s where s.type!='admin' and s.id='"+uf.getValue()+"'");
		}
		else if(uf.getType().equals("course")){
			query  = s.createQuery("select s.id,s.name,s.course,s.dept,s.type from Signup s where s.type!='admin' and s.course='"+uf.getValue()+"'");
		}
		else if(uf.getType().equals("dept")){
			query  = s.createQuery("select s.id,s.name,s.course,s.dept,s.type from Signup s where s.type!='admin' and s.dept='"+uf.getValue()+"'");
		}
		else if(uf.getType().equals("year")){
			query  = s.createQuery("select s.id,s.name,s.course,s.dept,s.type from Signup s where s.type!='admin' and s.year='"+uf.getYear()+"'");
		}
		else{
			Query q = s.createQuery("select s.id,s.name,s.course,s.dept,s.type from Signup s where s.type!='admin'");
		}
		List<Signup []> value = (List<Signup []>)query.list();
		return value;
	}
	@Transactional
	public List reportdet(String task){
		Session s = sf.getCurrentSession();
		List<Signup[]> q = (List<Signup[]>)s.createQuery("select s.id,s.name,s.dept,s.uname from Signup s where s.course='"+hs.getAttribute("course")+"' and s.type!='staff' ORDER BY s.dept").list();
		List<Filedata[]> q1 = (List<Filedata[]>)s.createQuery("select s.id,s.mark from Filedata s where s.course='"+hs.getAttribute("course")+"' and s.topic_name='"+task+"'").list();
		int fg = 0;
		for(Object[] ss:q) {
			for(Object[] sa:q1) {
				fg=0;
				if(ss[0].equals(sa[0])) {
					if(sa[1]!=null) {
						ss[3]=sa[1];
					}
					else {
						ss[3]="-";
					}
					fg=1;
					break;
				}
			}
			if(fg!=1) {
				ss[3]="Not Submitted";
			}
		}
		return q;	
	}
	@Transactional
	public String questionfile(String task) {
		Session s = sf.getCurrentSession();
		List<String> filename = s.createQuery("select s.filename from Tasksupload s where s.course='"+hs.getAttribute("course")+"' and s.topic_name='"+task+"'").list();
		if(filename.isEmpty()) {
			return null;
		}
		return filename.get(0);
	}
	@Transactional
	public List materialfile() {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.filename from Studymaterials s where s.course='"+hs.getAttribute("course")+"'");
		List<Studymaterials[]> task =(List<Studymaterials[]>) q.list();
		if(task.isEmpty()) {
			return null;
		}
		return task;
	}
	@Transactional
	public void deletematerial(String filename,HttpServletRequest request) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("delete from Studymaterials s where s.filename='"+filename+"' and s.course='"+hs.getAttribute("course")+"'");
		q.executeUpdate();
		File ff = new File(request.getServletContext().getRealPath("Files/"+hs.getAttribute("course")+"/"+"Materials"));
		File file = new File(ff.toString()+"\\"+filename);
		System.out.println(ff.toString());
		file.delete();
	}
	@Transactional
	public void uploadmaterial(com.fu.model.File files,HttpServletRequest request) {
		Session s = sf.getCurrentSession();
		Studymaterials sm = new Studymaterials();
		sm.setCourse(hs.getAttribute("course").toString());
		if(files.getFile()!=null) {
			sm.setFilename(files.getFile().getOriginalFilename());
			try {
				File ff = new File(request.getServletContext().getRealPath("Files/"));
				File file= new File(ff.toString()+"\\"+hs.getAttribute("course"));
		        if (!file.exists()) {
		            if (file.mkdir()) {
		            }
		        }
		        File file1 = new File(file.toString()+"\\Materials");
		        if (!file1.exists()) {
		            if (file1.mkdir()) {
		            }
		        }
		        InputStream is = files.getFile().getInputStream();
				OutputStream os=null;
		        if(files.getFile().getSize()>0){
				is=files.getFile().getInputStream();
				os=new FileOutputStream(file1+"\\"+sm.getFilename());
				byte[] byt = new byte[81920];
				int readbytes=0;
				while((readbytes=is.read(byt,0,81920))!=-1){
					os.write(byt, 0, readbytes);
				}
				os.close();
				is.close();
			}
			}
			catch(Exception e) {
				System.out.println("Failed!");
				e.printStackTrace();
			}
		}
		s.save(sm);
	}
	@Transactional
	public List allsubmissions(String id,String topic) {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.filename from Oldsubmissions s where s.id='"+id+"' and s.topic_name='"+topic+"'");
		List<Oldsubmissions[]> oss = (List<Oldsubmissions[]>) q.list();
		return oss;
	}
	@Transactional
	public List graph() {
		Session s = sf.getCurrentSession();
		Query q = s.createQuery("select s.mark from Filedata s where s.id='"+hs.getAttribute("id")+"' ORDER BY s.topic_name");
		List<Filedata[]> oss = (List<Filedata[]>) q.list();
		return oss;
	}
	@Transactional
	public List stafftaskfilter(Userfilter uf){
		Session s = sf.getCurrentSession();
		List<Filedata[]> q;
		if(uf.getType().equals("dept")) {
			q = (List<Filedata[]>)s.createQuery("select s.id,s.name,s.filename,s.dept,s.status,s.count,s.mark from Filedata s where s.topic_name='"+uf.getYear()+"' and s.course='"+hs.getAttribute("course")+"' and s.dept='"+uf.getValue()+"'").list();
		}
		else if(uf.getType().equals("id")) {
			q = (List<Filedata[]>)s.createQuery("select s.id,s.name,s.filename,s.dept,s.status,s.count,s.mark from Filedata s where s.topic_name='"+uf.getYear()+"' and s.course='"+hs.getAttribute("course")+"' and s.id='"+uf.getValue()+"'").list();
		}
		else {
			q = (List<Filedata[]>)s.createQuery("select s.id,s.name,s.filename,s.dept,s.status,s.count,s.mark from Filedata s where s.topic_name='"+uf.getYear()+"' and s.course='"+hs.getAttribute("course")+"'").list();
		}
		if(q.isEmpty()) {
			q = (List<Filedata[]>)s.createQuery("select s.id,s.name,s.filename,s.dept,s.status,s.count,s.mark from Filedata s where s.topic_name='"+uf.getYear()+"' and s.course='"+hs.getAttribute("course")+"'").list();
		}
		return q;	
	}
	@Transactional
	public void edituser(Signup ss) {
		Session s = sf.getCurrentSession();
		System.out.println(ss.getId());
		Query q = s.createQuery("update Signup s set s.name='"+ss.getName()+"',s.year='"+ss.getYear()+"',s.dept='"+ss.getDept()+"',s.pwd='"+ss.getPwd()+"' where s.id='"+ss.getId()+"'");
		q.executeUpdate();
	}
}