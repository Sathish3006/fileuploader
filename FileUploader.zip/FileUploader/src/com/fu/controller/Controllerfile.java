package com.fu.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fu.dao.ProjectDAO;
import com.fu.model.Filedata;
import com.fu.model.Signup;
import com.fu.model.Studymaterials;
import com.fu.model.Tasksupload;
import com.fu.model.Userfilter;

@Controller
public class Controllerfile {
	@Autowired
	HttpSession sess;
	@Autowired
	ProjectDAO pdao;
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String login() {
		sess.setAttribute("log", "not");
		return "redirect:/login";
	}
	@RequestMapping(value="/login")
	public String loginchk() {
		if(sess.getAttribute("pos")==null) {
			return "login";
		}
		else if(sess.getAttribute("pos")!=null) {
			if(sess.getAttribute("pos").equals("student")) {
				
				return "redirect:/studentpage";
			}
			else if(sess.getAttribute("pos").equals("staff")) {
				return "redirect:/staffpage";
			}
			else if(sess.getAttribute("pos").equals("admin")) {
				return "redirect:/adminpage";
			}
		}
		return "login";
	}
	@RequestMapping(value="/loginchk")
	public String loginvalidate(@ModelAttribute Signup ss) {
		if(sess.getAttribute("pos")==null) {
			String id = pdao.loginvalidate(ss);
			if(id!=null) {
				sess.setAttribute("id", id);
				sess.setAttribute("name", pdao.username(id));
				sess.setAttribute("pos", pdao.userposition(id));
				sess.setAttribute("course", pdao.usercourse(id));
				sess.setAttribute("log", "not");
			}
			else {
				sess.setAttribute("log","wrong");
				return "redirect:/login";
			}
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/studentpage")
	public String studentpage(Model model) {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("student")) {
			model.addAttribute("task",pdao.getTask());
			model.addAttribute("material",pdao.materialfile());
			return "studentpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/staffpage")
	public String staffpage(Model model) {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("unseen",pdao.countseen());
			return "staffpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/adminpage")
	public String adminpage(Model model) {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("admin")) {
			model.addAttribute("det",pdao.adminuserdetails());
			return "adminpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/adminuserpage",method=RequestMethod.GET)
	public String adminuserpage(Model model,@ModelAttribute Userfilter uf) {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("admin")) {
			model.addAttribute("det",pdao.adminfilter(uf));
			return "adminpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	public String logout() {
		sess.invalidate();
		sess.setAttribute("log", "not");
		return "redirect:/login";
	}
	@RequestMapping(value="/adminaddusers")
	public String addusers() {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("admin")) {
			return "adminaddusers";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/signup")
	public String signupuser(@ModelAttribute Signup ss) {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("admin")) {
			pdao.signupuser(ss);
			return "adminpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/profile")
	public String profileupdate(Model model) {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else{
			model.addAttribute("unseen",pdao.countseen());
			model.addAttribute("graph",pdao.graph());
			model.addAttribute("detail",pdao.userdetails());
			return "profile";
		}
		
	}
	@RequestMapping(value="/filesignup")
	public String signupusers(@ModelAttribute com.fu.model.File file) throws IOException {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("admin")) {
			pdao.signupmany(pdao.convert(file.getFile()));
			return "adminpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/addtask",method=RequestMethod.POST)
	public String addtask(@ModelAttribute com.fu.model.File file,Model model,HttpServletRequest req){
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("unseen",pdao.countseen());
			pdao.uploadtask(file,req);
			return "staffpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/taskdetails")
	public String taskdetails(@RequestParam("name") String name,Model model) throws IOException{
		System.out.println(name);
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("student")) {
			model.addAttribute("question",pdao.taskdetails(name));
			model.addAttribute("topic",name);
			model.addAttribute("date",pdao.taskdatedetails(name));
			model.addAttribute("filename", pdao.questionfile(name));
			model.addAttribute("file",pdao.filedownload(name));
			return "studenttaskpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/fileupload",method=RequestMethod.POST)
	public String fileupload(@ModelAttribute com.fu.model.File fd,HttpServletRequest req) throws IOException{
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("student")) {
			pdao.fileupload(fd,req);
			return "redirect:/studentpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/stafftaskedit")
	public String edittask(Model model){
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("unseen",pdao.countseen());
			model.addAttribute("task",pdao.edittask());
			return "staffedittask";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/edittaskdetails")
	public String edittaskdetails(@RequestParam("name") String name,Model model) throws IOException{
		System.out.println(name);
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("topic",name);
			model.addAttribute("question",pdao.taskdetails(name));
			model.addAttribute("date",pdao.tasklastdate(name));
			model.addAttribute("filename",pdao.taskfilename(name));
			return "stafftaskcorrection";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/staffupdatetask",method=RequestMethod.POST)
	public String staffupdatetask(@ModelAttribute com.fu.model.File tu,Model model,HttpServletRequest req) throws IOException{
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("unseen",pdao.countseen());
			pdao.updatetaskdetails(tu,req);
			return "redirect:/staffpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/studentdetails")
	public String studentdetails(Model model){
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("unseen",pdao.countseen());
			model.addAttribute("detail",pdao.studentdetails());
			return "studentdetails";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/tasksubmissions")
	public String tasksubmissions(Model model) {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("unseen",pdao.countseen());
			model.addAttribute("task",pdao.stafftaskname());
			return "stafftaskview";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/stafftaskdetails")
	public String stafftasksdetails(@RequestParam("name") String name,Model model) throws IOException{
		System.out.println(name);
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("task",pdao.stafftaskdetails(name));
			model.addAttribute("topic",name);
			model.addAttribute("unseen",pdao.countseen());
			return "stafftaskcheck";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/profileupdate")
	public String profileupdate(@ModelAttribute Signup ss,Model model){
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else {
			model.addAttribute("unseen",pdao.countseen());
			pdao.updateprofile(ss);
			return "redirect:/login";
		}
	}
	@RequestMapping(value="/markset")
	public String staffmarkset(@ModelAttribute Filedata fd,Model model) throws IOException{
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			pdao.markupdate(fd);
			model.addAttribute("unseen",pdao.countseen());
			model.addAttribute("task",pdao.stafftaskdetails(fd.getTopic_name()));
			model.addAttribute("topic",fd.getTopic_name());
			return "stafftaskcheck";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/adminviewuser")
	public String adminviewuser(@ModelAttribute Signup ss,Model model) {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("admin")) {
			model.addAttribute("det",pdao.viewuser(ss));
			return "adminuserview";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/admindeleteuser")
	public String admindeleteuser(@ModelAttribute Signup ss) {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("admin")) {
			pdao.deleteuser(ss);
			return "redirect:/adminpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/download", method = RequestMethod.GET)
    public void downloadFile(HttpServletRequest request,HttpServletResponse response) throws IOException {
		String id=request.getParameter("id");
		String task = request.getParameter("task");
		String dataDirectory = request.getServletContext().getRealPath("Files/"+id+"/"+task);
		String filename=request.getParameter("filename");
		Path file = Paths.get(dataDirectory, filename);
		System.out.println(file.toString());
		if (Files.exists(file)) 
		{
			response.setContentType("APPLICATION/OCTET-STREAM");
			response.addHeader("Content-Disposition", "attachment; filename="+filename);
			try 
			{
				Files.copy(file, response.getOutputStream());
				response.getOutputStream().flush();
			} 
			catch (IOException ex) {
				ex.printStackTrace();
			}
		}
    }
	@RequestMapping(value="/studenttaskreport")
	public String studenttaskreport(Model model){
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("unseen",pdao.countseen());
			model.addAttribute("topic",pdao.edittask());
			return "stafftaskreport";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/taskreportdet")
	public String taskreportdetails(@RequestParam("task") String task,Model model){
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("unseen",pdao.countseen());
			model.addAttribute("det", pdao.reportdet(task));
			return "staffreportdet";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/materialpage")
	public String materialpage(Model model){
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("unseen",pdao.countseen());
			model.addAttribute("files",pdao.materialfile());
			return "staffmaterials";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/addmaterials")
	public String addmaterials(@ModelAttribute com.fu.model.File file,Model model,HttpServletRequest req){
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			pdao.uploadmaterial(file, req);
			return "redirect:/materialpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/deletematerials")
	public String deletematerials(@ModelAttribute Studymaterials sm,HttpServletRequest req){
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			System.out.println(sm.getFilename());
			pdao.deletematerial(sm.getFilename(),req);
			return "redirect:/materialpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/allsubmissions")
	public String allsubmissions(Model model,HttpServletRequest request){
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			
			model.addAttribute("unseen",pdao.countseen());
			model.addAttribute("files",pdao.allsubmissions(request.getParameter("id"), request.getParameter("topic")));
			model.addAttribute("id",request.getParameter("id"));
			model.addAttribute("topic",request.getParameter("topic"));
			return "staffallsubmissions";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/stafffilter")
	public String stafffilter(Model model,@ModelAttribute Userfilter uf){
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("staff")) {
			model.addAttribute("unseen",pdao.countseen());
			model.addAttribute("task",pdao.stafftaskfilter(uf));
			model.addAttribute("topic",uf.getYear());			
			return "stafftaskcheck";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/adminuserupdate")
	public String adminuserupdate(@ModelAttribute Signup ss) {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("admin")) {
			pdao.edituser(ss);
			return "redirect:/adminpage";
		}
		return "redirect:/login";
	}
	@RequestMapping(value="/admindelete")
	public String admindelete(@ModelAttribute Signup ss) {
		if(sess.getAttribute("pos")==null) {
			return "redirect:/login";
		}
		else if(sess.getAttribute("pos").equals("admin")) {
			return "admindelete";
		}
		return "redirect:/login";
	}
}
